package com.tcs.springbootdemo.model;

import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Department")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Department {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "departmentId")
	private long departmentId;
	@Column(insertable = false, updatable = false)
	private long organizationId;
	@Column(name="name")
	private String name;
	
	@OneToMany(mappedBy = "department" , fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
	private Set<Employee> employees = new HashSet<>();
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="organizationId")
	private Organization organization;
	
	
	/*public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Department(long departmentId, long organizationId, String name, List<Employee> employees) {
		super();
		this.departmentId = departmentId;
		this.organizationId = organizationId;
		this.name = name;
		this.employees = employees;
	}
	
	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", organizationId=" + organizationId + ", name=" + name + "]";
	}

	public long getId() {
		return departmentId;
	}
	public void setId(long departmentId) {
		this.departmentId = departmentId;
	}
	public long getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(long organizationId) {
		this.organizationId = organizationId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}*/
}
