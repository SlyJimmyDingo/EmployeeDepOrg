package com.tcs.springbootdemo.service;

import java.util.*;

import com.tcs.springbootdemo.dao.OrganizationDAO;
import com.tcs.springbootdemo.model.Department;
import com.tcs.springbootdemo.model.Employee;
import com.tcs.springbootdemo.model.Organization;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrganizationServiceImpl implements OrganizationService {

	@Autowired
	private OrganizationDAO organizationDao;
	
	@Override
	public String addOrganization(Organization organization) {
		// TODO Auto-generated method stub
		return organizationDao.addOrganization(organization);
	}
	
	@Override
	public String updateOrganization(Organization organization, long id) {
		// TODO Auto-generated method stub
		return organizationDao.updateOrganization(organization, id);
	}
	
	@Override
	public String deleteOrganization(Organization organization, long id){
		// TODO Auto-generated method stub
		return organizationDao.updateOrganization(organization, id);
	}	

	@Override
	public Optional<Organization> findById(long id){
		// TODO Auto-generated method stub
		return organizationDao.findById(id);
	}
	
	@Override
	public Optional<List<Employee>> getEmployees(long id) {
		// TODO Auto-generated method stub
		return organizationDao.getEmployees(id);
	}
	
	@Override
	public Optional<List<Department>> getDepartments(long id){
		// TODO Auto-generated method stub
		return organizationDao.getDepartments(id);
	}
	
	
	@Override
	public Optional<List<Organization>> getOrganizations() {
		// TODO Auto-generated method stub
		return organizationDao.getOrganizations();
	}

}
