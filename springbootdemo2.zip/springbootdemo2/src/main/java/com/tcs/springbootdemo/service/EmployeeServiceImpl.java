package com.tcs.springbootdemo.service;

import java.util.*;

import com.tcs.springbootdemo.dao.EmployeeDAO;
import com.tcs.springbootdemo.model.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO EmployeeDao;
	
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return EmployeeDao.addEmployee(employee);
	}
	
	@Override
	public String updateEmployee(Employee employee, long id) {
		// TODO Auto-generated method stub
		return EmployeeDao.updateEmployee(employee, id);
	}
	
	@Override
	public String deleteEmployee(Employee employee, long id) {
		// TODO Auto-generated method stub
		return EmployeeDao.deleteEmployee(employee, id);
	}	

	@Override
	public Optional<Employee> findById(long id) {
		// TODO Auto-generated method stub
		return EmployeeDao.findById(id);
	}
	
	@Override
	public Optional<List<Employee>> getEmployees() {
		// TODO Auto-generated method stub
		return EmployeeDao.getEmployees();
	}
	
	@Override
	public Optional<List<Employee>> findByOrganizationId(long id) {
		// TODO Auto-generated method stub
		return EmployeeDao.findByOrganizationId(id);
	}

}
