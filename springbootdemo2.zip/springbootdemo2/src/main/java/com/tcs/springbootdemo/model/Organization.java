package com.tcs.springbootdemo.model;
import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Organization")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Organization {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "organizationId")
	private long organizationId;
	@Column(name="name")
	private String name;
	private String address;
	
	@OneToMany(mappedBy = "organization" , fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
	private Set<Employee> employees = new HashSet<>();
	
	@OneToMany(mappedBy = "organization" , fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
	private Set<Department> departments = new HashSet<>();

	
	/*public Organization() {
		super();
		}
	
	public Organization(long id, String name, String address, List<Department> departments, List<Employee> employees) 
	{
		super();
		this.organizationId = id;
		this.name = name;
		this.address = address;
		this.departments = departments;
		this.employees = employees;
	}
	
	@Override
	public String toString() {
		return "Organization [organizationId=" + organizationId + ", name=" + name + ", address=" + address + "]";
	}

	public long getId() {
		return organizationId;
	}
	public void setId(long id) {
		this.organizationId = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<Department> getDepartments() {
		return departments;
	}
	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}*/
	
	
}
