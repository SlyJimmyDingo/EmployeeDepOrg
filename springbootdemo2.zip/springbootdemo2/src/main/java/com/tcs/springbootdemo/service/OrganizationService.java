package com.tcs.springbootdemo.service;

import java.util.List;
import java.util.Optional;

import com.tcs.springbootdemo.model.Department;
import com.tcs.springbootdemo.model.Employee;
import com.tcs.springbootdemo.model.Organization;

public interface OrganizationService {
	
	public String addOrganization(Organization organization);
	public String updateOrganization(Organization organization, long id);
	public String deleteOrganization(Organization organization, long id);
	public Optional<Organization> findById(long id);
	public Optional<List<Employee>> getEmployees(long id);
	public Optional<List<Department>> getDepartments(long id);
	public Optional<List<Organization>> getOrganizations();

}
