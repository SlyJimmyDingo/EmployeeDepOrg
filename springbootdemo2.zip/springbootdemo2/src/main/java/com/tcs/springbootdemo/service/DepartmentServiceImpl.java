package com.tcs.springbootdemo.service;

import java.util.*;

import com.tcs.springbootdemo.dao.DepartmentDAO;
import com.tcs.springbootdemo.model.Department;
import com.tcs.springbootdemo.model.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentDAO departmentDao;
	
	@Override
	public String addDepartment(Department department) {
		// TODO Auto-generated method stub
		return departmentDao.addDepartment(department);
	}
	
	@Override
	public String updateDepartment(Department department, long id) {
		// TODO Auto-generated method stub
		return departmentDao.updateDepartment(department, id);
	}
	
	@Override
	public String deleteDepartment(Department department, long id){
		// TODO Auto-generated method stub
		return departmentDao.updateDepartment(department, id);
	}	

	@Override
	public Optional<Department> findById(long id){
		// TODO Auto-generated method stub
		return departmentDao.findById(id);
	}
	
	@Override
	public Optional<List<Department>> getDepartments(){
		// TODO Auto-generated method stub
		return departmentDao.getDepartments();
	}
	
	@Override
	public Optional<List<Department>> findByOrganizationId(long id) {
		// TODO Auto-generated method stub
		return departmentDao.findByOrganizationId(id);
	}
	
	@Override
	public Optional<List<Employee>> getEmployees(long id) {
		// TODO Auto-generated method stub
		return departmentDao.getEmployees(id);
	}

}
