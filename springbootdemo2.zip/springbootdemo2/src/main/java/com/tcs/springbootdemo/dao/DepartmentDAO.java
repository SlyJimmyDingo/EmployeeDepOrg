package com.tcs.springbootdemo.dao;

import java.util.List;
import java.util.Optional;

import com.tcs.springbootdemo.model.Department;
import com.tcs.springbootdemo.model.Employee;

public interface DepartmentDAO {
	
	public String addDepartment(Department department);
	public String updateDepartment(Department department, long id);
	public String deleteDepartment(Department department, long id);
	public Optional<Department> findById(long id);
	public Optional<List<Department>> getDepartments();
	public Optional<List<Department>> findByOrganizationId(long id);
	public Optional<List<Employee>> getEmployees(long id);
	
}

