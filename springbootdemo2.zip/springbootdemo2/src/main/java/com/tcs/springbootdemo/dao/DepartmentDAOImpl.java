package com.tcs.springbootdemo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tcs.springbootdemo.model.Department;
import com.tcs.springbootdemo.model.Employee;
import com.tcs.springbootdemo.utils.DBUtils;

@Repository
public class DepartmentDAOImpl implements DepartmentDAO {
	
	@Autowired
	DBUtils dbUtils;

	@Override
	public String addDepartment(Department department) {
		
		Connection connection = dbUtils.getConnection();
		PreparedStatement preparedStatement = null;
		int result = 0;
		String query = "insert into DEPARTMENT (departmentid,organizationId,name) values(?,?,?)";
		try {
			 preparedStatement = connection.prepareStatement(query);
			 preparedStatement.setLong(1, department.getDepartmentId());
			 preparedStatement.setLong(2, department.getOrganizationId());
			 preparedStatement.setString(3, department.getName());
			 result = preparedStatement.executeUpdate();
			 
			 if(result>0)
			 {
				 connection.commit();
				 return "success";
				 
			 }
			 else {
				 return "fail";
			 }
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "fail";
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
	}
	
	@Override
	public String updateDepartment(Department department, long id) {
		
		Connection connection = dbUtils.getConnection();
		PreparedStatement preparedStatement = null;
		int result = 0;
		String query = "UPDATE DEPARTMENT set departmentId=?, organizationId=?, name=? WHERE departmentId=" + id;
		try {
			 preparedStatement = connection.prepareStatement(query);
			 preparedStatement.setLong(1, department.getDepartmentId());
			 preparedStatement.setLong(2, department.getOrganizationId());
			 preparedStatement.setString(3, department.getName());
			 result = preparedStatement.executeUpdate();
			 
			 if(result>0)
			 {
				 connection.commit();
				 return "success";
				 
			 }
			 else {
				 return "fail";
			 }
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "fail";
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
	}
	
	@Override
	public String deleteDepartment(Department department, long id) {
		
		Connection connection = dbUtils.getConnection();
		PreparedStatement preparedStatement = null;
		int result = 0;
		String query = "DELETE FROM DEPARTMENT WHERE departmentId=" + id;
		try {
			 preparedStatement = connection.prepareStatement(query);
			 result = preparedStatement.executeUpdate();
			 
			 if(result>0)
			 {
				 connection.commit();
				 return "success";
				 
			 }
			 else {
				 return "fail";
			 }
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "fail";
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		
	}
	
	@Override
	public Optional<Department> findById(long id) {
		Connection connection = dbUtils.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		Department department = null;
		String query = "select * from DEPARTMENT where departmentId=" + id;
		try {
			 preparedStatement = connection.prepareStatement(query);
			
			resultSet =  preparedStatement.executeQuery();
			 
			if(resultSet.next()) {
				department = new Department();
				department.setDepartmentId(resultSet.getLong("departmentId"));
				department.setOrganizationId(resultSet.getLong("organizationId"));
				department.setName(resultSet.getString("name"));				 
			}
			 
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Optional.empty();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.of(department);
	}
	
	@Override
	public Optional<List<Department>> getDepartments()
	{
		Connection connection = dbUtils.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Department department = null;
		List<Department> depList = new ArrayList<>();
		String query = "select * from DEPARTMENT order by departmentid";
		try {
			 preparedStatement = connection.prepareStatement(query);
			
			resultSet =  preparedStatement.executeQuery();
			 
			while(resultSet.next()) 
			{
				department = new Department();
				department.setDepartmentId(resultSet.getLong("departmentId"));
				department.setOrganizationId(resultSet.getLong("organizationId"));
				department.setName(resultSet.getString("name"));
				depList.add(department);
			}
			 
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Optional.empty();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.of(depList);
	}
	
	@Override
	public Optional<List<Department>> findByOrganizationId(long id)
	{
		Connection connection = dbUtils.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Department department = null;
		List<Department> depList = new ArrayList<>();
		String query = "select * from DEPARTMENT where organizationId=" + id;
		try {
			 preparedStatement = connection.prepareStatement(query);
			
			resultSet =  preparedStatement.executeQuery();
			 
			while(resultSet.next()) 
			{
				department = new Department();
				department.setDepartmentId(resultSet.getLong("departmentId"));
				department.setOrganizationId(resultSet.getLong("organizationId"));
				department.setName(resultSet.getString("name"));
				depList.add(department);
			}
			 
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return Optional.empty();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.of(depList);
	}
	
	@Override
	public Optional<List<Employee>> getEmployees(long id)
	{
		Connection connection = dbUtils.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Employee employee = null;
		List<Employee> empList = new ArrayList<>();
		String query = "select * from EMPLOYEE where departmentid=" + id;
		try {
			 preparedStatement = connection.prepareStatement(query);
			
			resultSet =  preparedStatement.executeQuery();
			 
			while(resultSet.next()) 
			{
				employee = new Employee();
				employee.setId(resultSet.getLong("id"));
				employee.setOrganizationId(resultSet.getLong("organizationId"));
				employee.setDepartmentId(resultSet.getLong("departmentId"));
				employee.setName(resultSet.getString("name"));
				employee.setAge(resultSet.getInt("age"));
				employee.setPosition(resultSet.getString("position"));
				empList.add(employee);
			}
			 
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return Optional.empty();
		}
		finally {
			dbUtils.closeConnection(connection);
		}
		return Optional.of(empList);
	}
	
}
