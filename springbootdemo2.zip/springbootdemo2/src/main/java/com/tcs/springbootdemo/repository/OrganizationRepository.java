package com.tcs.springbootdemo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.springbootdemo.model.Employee;
import com.tcs.springbootdemo.model.Department;
import com.tcs.springbootdemo.model.Organization;

@Repository
public interface OrganizationRepository extends JpaRepository<Organization, Long> 
{
	
}