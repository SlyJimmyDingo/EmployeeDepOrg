package com.tcs.employeerestapi.service;

import java.util.*;

import com.tcs.employeerestapi.model.Employee;

public interface EmployeeService {
	
	public Employee addEmployee(Employee employee);
	public Optional<Employee> getEmployeeById(int id);
	public void deleteEmployee(int id);
	public Optional<List<Employee>> getEmployees();
	public Optional<List<Employee>> findByOrganizationId(int id);
	
}
