package com.tcs.departmentrestapi.service;

import java.util.*;

import com.tcs.departmentrestapi.model.Department;
import com.tcs.departmentrestapi.repository.DepartmentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository departmentRepository;
	
	@Override
	public Department addDepartment(Department department) {
		Department department2 = null;
		try {
			department2 = departmentRepository.save(department);
			return department2;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public Optional<Department> getDepartmentById(int id) {
		// TODO Auto-generated method stub	
		return departmentRepository.findById(id);
	}

	@Override
	public void deleteDepartment(int id) {
		// TODO Auto-generated method stub
		departmentRepository.deleteById(id);
	}

	@Override
	public Optional<List<Department>> getDepartments() {
		// TODO Auto-generated method stub
		return Optional.ofNullable(departmentRepository.findAll());
	}

	@Override
	public Optional<List<Department>> findByOrganizationId(int id) {
		// TODO Auto-generated method stub
		return Optional.ofNullable(departmentRepository.findByOrganizationId((id)));
		//return null;
	}
	

}
