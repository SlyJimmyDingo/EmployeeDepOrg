package com.tcs.departmentrestapi.service;

import java.util.*;

import com.tcs.departmentrestapi.model.Department;

public interface DepartmentService {
	
	public Department addDepartment(Department department);
	public Optional<Department> getDepartmentById(int id);
	public void deleteDepartment(int id);
	public Optional<List<Department>> getDepartments();
	public Optional<List<Department>> findByOrganizationId(int id);
	
}
