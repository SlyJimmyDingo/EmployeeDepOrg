package com.tcs.departmentrestapi.exception;

public class ResourceNotFoundException extends Exception {

	public ResourceNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
