package com.tcs.organizationrestapi.service;

import java.util.*;

import com.tcs.organizationrestapi.model.Organization;

public interface OrganizationService {
	
	public Organization addOrganization(Organization organization);
	public Optional<Organization> getOrganizationById(int id);
	public void deleteOrganization(int id);
	public Optional<List<Organization>> getOrganizations();
	
}
