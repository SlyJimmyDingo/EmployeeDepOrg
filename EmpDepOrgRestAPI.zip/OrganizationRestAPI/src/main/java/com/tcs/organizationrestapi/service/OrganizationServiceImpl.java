package com.tcs.organizationrestapi.service;

import java.util.*;

import com.tcs.organizationrestapi.model.Organization;
import com.tcs.organizationrestapi.repository.OrganizationRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrganizationServiceImpl implements OrganizationService {

	@Autowired
	OrganizationRepository organizationRepository;
	
	@Override
	public Organization addOrganization(Organization organization) {
		Organization organization2 = null;
		try {
			organization2 = organizationRepository.save(organization);
			return organization2;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public Optional<Organization> getOrganizationById(int id) {
		// TODO Auto-generated method stub	
		return organizationRepository.findById(id);
	}

	@Override
	public void deleteOrganization(int id) {
		// TODO Auto-generated method stub
		organizationRepository.deleteById(id);
	}

	@Override
	public Optional<List<Organization>> getOrganizations() {
		// TODO Auto-generated method stub
		return Optional.ofNullable(organizationRepository.findAll());
	}

	

}
