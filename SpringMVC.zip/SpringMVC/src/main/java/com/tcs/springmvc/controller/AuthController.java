package com.tcs.springmvc.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.hibernate.annotations.BatchSize;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Value;


import com.tcs.springmvc.model.Login;
import com.tcs.springmvc.repository.LoginRepository;
import com.tcs.springmvc.repository.RegistrationRepository;

@Controller
@RequestMapping(path="/auth")
public class AuthController {

	@Autowired
	LoginRepository loginRepository;
	
	@Autowired
	RegistrationRepository registrationRepository;
	
	@GetMapping("/login.html")
	public String getLoginPage() {
		return "login";
	}
	
	@GetMapping("/register.html")
	public String getRegisterPage() {
		return "register";
	}
	
	@PostMapping("/login.html")
	public ModelAndView validateLogin(@ModelAttribute @Valid Login login,BindingResult result) {
		System.out.println("Validate Login: "+login);
		ModelAndView modelAndView = new ModelAndView();
		if(result.hasErrors()) {
			result.getFieldErrors().forEach(e->{
				modelAndView.addObject(e.getField(), e.getDefaultMessage());
				System.out.println(e.getDefaultMessage() + " "+ e.getField());
				
			});
			modelAndView.setViewName("login");
			return modelAndView;
		}
		
		if(login.equals(loginRepository.findById(login.getUserName()).get())) {
			System.out.println("success");
		}
		else {
			System.out.println("fail");
		}
		modelAndView.setViewName("redirect:/dashboard");
		return modelAndView;
	}
	
	@PostMapping("/register.html")
	public ModelAndView Register(@ModelAttribute @Valid Login login,BindingResult result) {
		System.out.println("Validate New User: "+login);
		ModelAndView modelAndView = new ModelAndView();
		if(result.hasErrors()) {
			result.getFieldErrors().forEach(e->{
				modelAndView.addObject(e.getField(), e.getDefaultMessage());
				System.out.println(e.getDefaultMessage() + " "+ e.getField());
				
			});
			modelAndView.setViewName("register");
			return modelAndView;
		}
	
		loginRepository.save(login);

		modelAndView.setViewName("redirect:/dashboard");
		return modelAndView;
	}
}